from spelltutor.core.play import Tutor

def main():
    print("Welcome to SPELL TUTOR \n")
    user_name = input("Enter your name: ")
    age = input("Enter your age: ")
    _display_welcome_message(user_name)


def _display_welcome_message(user_name):
    print("Hi {}, What would you like to learn? Choose from below and enter the number \n".format(user_name))
    print("1. Spellings \n")
    print("2. Jumbled words \n")
    number = input("Enter your choice: ")
    Tutor(number).play()


if __name__ == '__main__':
    main()